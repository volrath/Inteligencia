#ifndef __IA1_H
#define __IA1_H

int ia1(char *carnet, double x[10], double *z);

#endif
